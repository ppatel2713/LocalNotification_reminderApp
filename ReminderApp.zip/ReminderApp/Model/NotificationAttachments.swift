//
//  NotificationAttachments.swift
//  ReminderApp
//
//  Created by Prachi on 2021-03-21.
//

import Foundation

enum  NotificationAttachments : String{
    case timer = "userNotifucation.attachment.timer"
    
    case date = "userNotifucation.attachment.date"
    
    case location = "userNotifucation.attachment.location"
}


