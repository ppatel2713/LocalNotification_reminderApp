//
//  NotificationCategory.swift
//  ReminderApp
//
//  Created by Prachi on 2021-03-21.
//

import Foundation
enum NotificationCategory  : String {
    
    case timer = "userNotification.category.timer"
    case date = "userNotification.category.date"
    case location = "userNotification.category.location"
}
