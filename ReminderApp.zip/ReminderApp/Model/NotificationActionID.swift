//
//  NotificationActionID.swift
//  ReminderApp
//
//  Created by Prachi on 2021-03-21.
//

import Foundation
enum NotificationActionID : String //handle actions of notification
{
    case timer = "userNotifucation.action.timer"
    
    case date = "userNotifucation.action.date"
    
    case location = "userNotifucation.action.location"
}
