//
//  CLService.swift
//  ReminderApp
//
//  Created by Prachi on 2021-03-21.
//

import Foundation
import CoreLocation

class CLService : NSObject { //this class will watching when location updated.
    private override init() {} //cannot create new instance

    static let shared = CLService() //singleton
    
    let locationManager = CLLocationManager()
    var shouldSetRegion = true
    func authorize()
    {
        locationManager.requestAlwaysAuthorization()
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.delegate = self
    }
    
    func updateLocation() {
        shouldSetRegion = true //when user want to update location shouldSetRegion will became true
        locationManager.startUpdatingLocation()
    }
}


extension CLService : CLLocationManagerDelegate
{
    //this method is call every time when region is change, so we create shouldSetRegion as a flag, if its true it will excute code and set shouldSetRegion false
    
    //also add 2 key in info.plist
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print("Locations changing")
        guard let currentLocation = locations.first,shouldSetRegion else {return} //first time selected location is stored in current location
        shouldSetRegion = false //once it will become false will not call this functiona again
        let region = CLCircularRegion(center: currentLocation.coordinate, radius: 20, identifier: "startPosition")
        manager.startMonitoring(for: region)
    }
    
    func locationManager(_ manager: CLLocationManager, didEnterRegion region: CLRegion) {
        print("didEnterRegion")
        NotificationCenter.default.post(name: NSNotification.Name("internalNotification.enteredRegion"), object: nil)
    } //whenever we enterd into oiginal(first)region code will be call, will send internal notification. create observer with same name.
    //it will pass this notification with name
}
