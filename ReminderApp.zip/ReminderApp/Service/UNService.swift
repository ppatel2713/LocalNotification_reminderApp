//
//  UNService.swift
//  ReminderApp
//
//  Created by Prachi on 2021-03-21.
//



//usernotification service or helper class
import UIKit
import UserNotifications

class UNService : NSObject{
    
    var bedgeNumber : Int = 0
//this class observe notifications, observe specific events means notification was accessed, pop-up, app in foreground or in Background so this events handle notifications. so have user unservice as delegate(to observe all of that info). but in order to set unservice delegate its self, it has to subclass of NSobject class.
    
    private override init()
    {}
    //this means can't make UNService object anywhere else. you need to always refernce shared variable. help of shared use functions and variables
    
    //when working with data, service, notification, networking, threading always make singleton service or instance
    static let shared = UNService()
    let unCenter = UNUserNotificationCenter.current()
    
    //1 --> request permission to set alert to user
    func authorize()
    {
        let options : UNAuthorizationOptions = [.alert,.badge,.sound,.carPlay] //req permission some specific option like bedge, sound etc.
        unCenter.requestAuthorization(options: options) { [self] (granted, error) in
            guard granted else {//write code here if user denies the permission to get notifications from user
                print("No permission granted")
                return
            }
            //means granted is true, user give permission so its true
            DispatchQueue.main.async {
                UIApplication.shared.applicationIconBadgeNumber = bedgeNumber
            }
        }
        self.configure()
    }
    
    
    func configure() {
        unCenter.delegate = self
        setupActionsAndCategory()
    }
    func setupActionsAndCategory()
    {
        let timerAction = UNNotificationAction(
            identifier: NotificationActionID.timer.rawValue,
            title: "Run Some Timer",
            options:[.authenticationRequired] ) //authenticationRequired user have to unlock phone and then code will run till then app will keep in Background
        let dateAction = UNNotificationAction(
            identifier: NotificationActionID.date.rawValue,
            title: "Run date ",
            options:[.destructive] ) //destructive button will convert into red
        let locationAction = UNNotificationAction(
            identifier: NotificationActionID.location.rawValue,
            title: "Run Some Loaction",
            options:[.foreground] )
        
        //add action into category
        let timerCategory = UNNotificationCategory(identifier: NotificationCategory.timer.rawValue, actions:[timerAction], intentIdentifiers: [])
        let dateCategory = UNNotificationCategory(identifier: NotificationCategory.date.rawValue, actions:[dateAction], intentIdentifiers: [])
        let locationCategory = UNNotificationCategory(identifier: NotificationCategory.location.rawValue, actions:[locationAction], intentIdentifiers: [])
        //add category into notification
        unCenter.setNotificationCategories([timerCategory,dateCategory,locationCategory])
        
    }//which action attached to which category
    
    
    func getAttachment(for id : NotificationAttachments) ->UNNotificationAttachment? {
        var imageName : String
        switch id {
        case .timer: imageName = "TimeAlert"
        case .date: imageName = "DateAlert"
        case .location: imageName = "LocationAlert"
        }
        
        guard let url = Bundle.main.url(forResource: imageName, withExtension: "png") else {
            return nil
        }
        do{
            let attachment  = try UNNotificationAttachment(identifier: id.rawValue, url: url) //options for meta data, whe type of file you are looking for
            return attachment
        }
        catch
        {
            return nil
        }
    }
    
    
    func timerRequest(with interval : TimeInterval)
    {
        let content = UNMutableNotificationContent()
        content.title = "Timer Finished"
        content.body = "Your timer is done!"
        content.sound = .default
        content.badge = NSNumber(value: bedgeNumber + 1)
        content.categoryIdentifier = NotificationCategory.timer.rawValue
        
        if let attachment = getAttachment(for: .timer)
        {
            content.attachments = [attachment]
        }
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: interval, repeats: false) //UNNotificationTrigger basic, repeat can happen on time trigger interval if time is more than 60 seconds, if you want timer to repeat set interval more than 60 seconds. if set under 60 seconds it will crash the app
        let request = UNNotificationRequest(
            identifier: "userNotification.timer",
            content:content,
            trigger:trigger) //identifier give unique name to notification, set identifier when you want to access specific notification
        unCenter.add(request, withCompletionHandler: nil)
    }
    
    func dateRequest(with components  : DateComponents)
    {
        let content = UNMutableNotificationContent()
        content.title = "Date trigger"
        content.body = "It is now the future!"
        content.sound = .default
        content.categoryIdentifier = NotificationCategory.date.rawValue
        content.badge = NSNumber(value: bedgeNumber + 1)
        if let attachment = getAttachment(for: .date)
        {
            content.attachments = [attachment]
        }
        let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: false)
        let request = UNNotificationRequest(identifier: "userNotification.date", content: content, trigger: trigger)
        unCenter.add(request, withCompletionHandler: nil)
    }
    
    func locationRequest()
    {
        let content = UNMutableNotificationContent()
        content.title = "You have returned"
        content.body = "welcome back!"
        content.sound = .default
        content.badge = NSNumber(value: bedgeNumber + 1)
        content.categoryIdentifier = NotificationCategory.location.rawValue
        if let attachment = getAttachment(for: .location)
        {
            content.attachments = [attachment]
        }
        let request = UNNotificationRequest(identifier: "userNotification.location", content: content, trigger: nil)
        
        unCenter.add(request, withCompletionHandler: nil)
    }
}


extension UNService : UNUserNotificationCenterDelegate
{
    func userNotificationCenter(_ center: UNUserNotificationCenter, didReceive response: UNNotificationResponse, withCompletionHandler completionHandler: @escaping () -> Void) {
        if let action = NotificationActionID(rawValue:response.actionIdentifier)
        {
            NotificationCenter.default.post(name: NSNotification.Name("internalNotification.handleAction"),object: action)
        } //will create internal notification
        
        completionHandler()
    } //invoke when user interact with notifications(tap on notification)
    
    func userNotificationCenter(_ center: UNUserNotificationCenter, willPresent notification: UNNotification, withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        let options : UNNotificationPresentationOptions = [.sound,.banner]
        completionHandler(options)
    } //excute when app is in foreground
}
