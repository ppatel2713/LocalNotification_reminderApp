//
//  ViewController.swift
//  ReminderApp
//
//  Created by Prachi on 2021-03-21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        UNService.shared.authorize() //this function can call on didFinishLaunching but best practise to call here and it will ask for user's permission to allow notification
        
        CLService.shared.authorize()
        
        NotificationCenter.default.addObserver(self, selector:#selector(didEnterRegion) , name: NSNotification.Name?(NSNotification.Name(rawValue: "internalNotification.enteredRegion")), object: nil) //handle notification from CLservice class. create some action on internalNotification.enteredRegion observer.
        
        NotificationCenter.default.addObserver(self, selector:#selector(handleAction) , name: NSNotification.Name?(NSNotification.Name(rawValue: "internalNotification.handleAction")), object: nil)
        //handle internal notification for handling actions on notification (UNService -> didReceiveresponse delegate)
    }
    
    @IBAction func onTimerTapped(_ sender: Any) {
        AlertService.actionSheet(in: self, title: "5 Seconds") {
            UNService.shared.timerRequest(with:5)
        }
    }
    @IBAction func onDateTapped(_ sender: Any) {
        
        AlertService.actionSheet(in: self, title: "Some Future Time") {
            var component = DateComponents()
            component.second = 0 //every time the clock hits 0 for the seconds notification triggerd
           // component.weekday = 1    //it means every sunday sunday-saturday (1-7)
            UNService.shared.dateRequest(with: component)
        }
    }
    @IBAction func onLocationTapped(_ sender: Any) {
        AlertService.actionSheet(in: self, title: "I return") {
            print("YEY!")
            CLService.shared.updateLocation()
        } //button tapped location is changed
    }
    
    @objc func didEnterRegion()
    {
        UNService.shared.locationRequest()
    }
    //didUpdateLocations in deleagate store first location for user. when user will be back on original region. CLService->didEnterRegion from delegates will call and internal notification create and that notfication has one observer (Viewcontroller->ViewDidLoad) and that observer has selector name didEnterRegion() where notification functions is called locationRequest() and notification generates.
    
    
    @objc func handleAction(_ sender : Notification)
    {
        guard let action = sender.object as? NotificationActionID else{return} //here checking which time of notification has came according to type of notification switch will work
        
        switch action {
        case .timer:
            print("Timer Logic")
        case .date:
            print("Date Logic")
        case .location:
            print("location logic")
        }
    } // when user tap on notification UNService -> didReceiveresponse delegate will call and there created one internal notification and handle that notification in viewController-> ViewDidLoad. ithas selector handleAction. handle action as per notification type.
    
}
